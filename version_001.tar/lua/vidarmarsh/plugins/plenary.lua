return {
    "nvim-lua/plenary.nvim",
    config = function()
        require("plenary")
    end,
}
